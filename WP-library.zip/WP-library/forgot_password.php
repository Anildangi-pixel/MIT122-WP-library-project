<?php require_once __DIR__ . '/includes/header.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if ($email=='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) { setFlash('error','Please provide a valid email.'); redirect('forgot_password.php'); }
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?'); $stmt->execute([$email]); $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { setFlash('error','No account with that email.'); redirect('forgot_password.php'); }
    $token = bin2hex(random_bytes(16)); $stmt = $pdo->prepare('INSERT INTO password_resets (user_id, token, created_at) VALUES (?, ?, NOW())'); $stmt->execute([$user['id'],$token]);
    $resetLink = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/reset_password.php?token=' . $token;
    setFlash('success','Password reset link (demo) created and shown below.'); $_SESSION['reset_link']=$resetLink; redirect('forgot_password.php');
}
?>
<h2>Forgot Password</h2>
<form method="post" class="form"><label>Email<input type="email" name="email" required></label><button type="submit">Send reset link</button></form>
<?php if (!empty($_SESSION['reset_link'])): ?><div class="note"><p><strong>Demo reset link:</strong></p><p><a href="<?php echo esc($_SESSION['reset_link']); ?>"><?php echo esc($_SESSION['reset_link']); ?></a></p></div><?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>