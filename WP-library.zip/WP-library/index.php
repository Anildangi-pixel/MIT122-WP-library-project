<?php 
require_once __DIR__ . '/includes/header.php';

$stmt = $pdo->query('SELECT id, title, author, category, image, description FROM books ORDER BY created_at DESC LIMIT 6');
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Hero Section -->
 <link rel="stylesheet" href="css/style.css">
<section class="hero">
  <h2>Welcome to WP Library</h2>
  <p>Explore knowledge, discover books, and fuel your future.</p>
  <a href="books.php" class="btn">Browse All Books</a>
</section>

<!-- Featured Books -->
<section class="featured">
  <h2> Featured Books</h2>
  <div class="book-grid">
    <?php foreach($books as $b): ?>
      <article class="book-card">
        <a href="book_view.php?id=<?php echo esc($b['id']); ?>">
          <img src="images/<?php echo esc($b['image']); ?>" alt="">
          <h3><?php echo esc($b['title']); ?></h3>
        </a>
        <p class="author"> <?php echo esc($b['author']); ?></p>
        <span class="category"><?php echo esc($b['category']); ?></span>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<!-- About Section -->
<section class="about">
  <h2>About WP Library</h2>
  <p>WP Library is an online educational platform designed to give students easy access to books, resources, and study materials anytime, anywhere.</p>
</section>

<!-- Categories -->
<section class="categories">
  <h2> Explore Categories</h2>
  <div class="cat-grid">
    <div class="cat-card">Science</div>
    <div class="cat-card">Technology</div>
    <div class="cat-card">History</div>
    <div class="cat-card">Fiction</div>
    <div class="cat-card">Education</div>
    <div class="cat-card">Philosophy</div>
  </div>
</section>

<!-- Contact -->
<section class="contact">
  <h2> Contact Us</h2>
  <p>Email: support@wplibrary.com</p>
  <p>Phone: +61 000 000</p>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>