<?php require_once __DIR__ . '/includes/header.php';

$q = trim($_GET['q'] ?? '');
$cat = trim($_GET['category'] ?? '');

// fetch categories
$cats_stmt = $pdo->query('SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != ""');
$categories = $cats_stmt->fetchAll(PDO::FETCH_COLUMN);

// build query
if ($q !== '' && $cat !== '') {
    $stmt = $pdo->prepare('SELECT id,title,author,category,image,description FROM books WHERE (title LIKE ? OR author LIKE ?) AND category = ? ORDER BY title');
    $like = '%'.$q.'%'; 
    $stmt->execute([$like,$like,$cat]);
} elseif ($q !== '') {
    $stmt = $pdo->prepare('SELECT id,title,author,category,image,description FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title');
    $like = '%'.$q.'%'; 
    $stmt->execute([$like,$like]);
} elseif ($cat !== '') {
    $stmt = $pdo->prepare('SELECT id,title,author,category,image,description FROM books WHERE category = ? ORDER BY title');
    $stmt->execute([$cat]);
} else {
    $stmt = $pdo->query('SELECT id,title,author,category,image,description FROM books ORDER BY title');
}
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<link rel="stylesheet" href="css/style.css">
<section class="books-header">
  <h2> Our Book Collection</h2>
  <p>Browse through our library. Use the search and category filter to find what you need.</p>
</section>

<form method="get" class="search-form">
  <input type="search" name="q" value="<?php echo esc($q); ?>" placeholder="Search by title or author">
  <select name="category">
    <option value="">All categories</option>
    <?php foreach($categories as $c): ?>
      <option value="<?php echo esc($c); ?>" <?php if($c===$cat) echo 'selected'; ?>>
        <?php echo esc($c); ?>
      </option>
    <?php endforeach; ?>
  </select>
  <button type="submit">Filter</button>
</form>

<?php if (empty($books)): ?>
  <p class="no-results">No books found. Try a different search or category.</p>
<?php else: ?>
  <div class="book-grid">
    <?php foreach($books as $b): ?>
      <article class="book-card">
        <a href="book_view.php?id=<?php echo esc($b['id']); ?>">
          <img src="images/<?php echo esc($b['image']); ?>" alt="">
          <h3><?php echo esc($b['title']); ?></h3>
        </a>
        <p class="author">By <?php echo esc($b['author']); ?></p>
        <p class="muted">Category: <?php echo esc($b['category']); ?></p>
      </article>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>