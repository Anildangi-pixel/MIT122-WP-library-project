<?php require_once __DIR__ . '/includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { setFlash('error','Invalid request'); redirect('books.php'); }
if (!isLoggedIn()) { setFlash('error','You must be logged in to borrow books.'); redirect('login.php'); }
$user_id = $_SESSION['user_id']; $book_id = (int)($_POST['book_id'] ?? 0);
$stmt = $pdo->prepare('SELECT available FROM books WHERE id = ?'); $stmt->execute([$book_id]); $b = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$b || !$b['available']) { setFlash('error','Book not available.'); redirect('book_view.php?id=' . $book_id); }
$due = date('Y-m-d', strtotime('+14 days'));
$stmt = $pdo->prepare('INSERT INTO borrows (user_id, book_id, borrow_date, due_date) VALUES (?, ?, CURDATE(), ?)'); $stmt->execute([$user_id,$book_id,$due]);
$stmt = $pdo->prepare('UPDATE books SET available = 0 WHERE id = ?'); $stmt->execute([$book_id]);
setFlash('success','Book borrowed successfully. Due date: ' . $due); redirect('account.php'); ?>