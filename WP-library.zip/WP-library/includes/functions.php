<?php
require_once __DIR__ . '/config.php';

function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['is_admin']) && $_SESSION['is_admin']; }
function redirect($url) { header('Location: ' . $url); exit; }
function setFlash($k,$m) { $_SESSION['flash'][$k]=$m; }
function getFlash($k){ if(!isset($_SESSION['flash'][$k])) return null; $m=$_SESSION['flash'][$k]; unset($_SESSION['flash'][$k]); return $m; }

function getUserById($id){
    global $pdo;
    $stmt = $pdo->prepare('SELECT id,name,email,is_admin,created_at FROM users WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getRecommendedBooks($exclude_id, $limit = 4){
    global $pdo;
    $stmt = $pdo->prepare('SELECT id,title,author,category,image,description FROM books WHERE id != ? ORDER BY RAND() LIMIT ?');
    $stmt->bindValue(1,$exclude_id,PDO::PARAM_INT);
    $stmt->bindValue(2,(int)$limit,PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>