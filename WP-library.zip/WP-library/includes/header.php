<?php require_once __DIR__ . '/functions.php'; ?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WP Library</title>
<link rel="stylesheet" href="/WP-library/css/layout.css">
<link rel="stylesheet" href="/WP-library/css/home.css"></head>
<body>
<header class="site-header">
  <div class="container">
    <h1 class="logo"><a href="/WP-library/index.php"><img src="/WP-library/images/logo.png" alt="WP Library logo" class="logo-img"> WP Library</a></h1>
    <nav>
      <a href="/WP-library/index.php">Home</a>
      <a href="/WP-library/books.php">Books</a>
      <a href="/WP-library/about.php">About</a>
      <a href="/WP-library/contact.php">Contact</a>
      <?php if (isLoggedIn()): ?>
        <a href="/WP-library/account.php">Account</a>
        <a href="/WP-library/logout.php">Logout</a>
        <?php if (isAdmin()): ?><a href="/WP-library/admin/dashboard.php">Admin</a><?php endif; ?>
      <?php else: ?>
        <a href="/WP-library/login.php">Login</a>
        <a href="/WP-library/register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
  <?php if ($m = getFlash('success')): ?><div class="flash success"><?php echo esc($m); ?></div><?php endif; ?>
  <?php if ($m = getFlash('error')): ?><div class="flash error"><?php echo esc($m); ?></div><?php endif; ?>