</main>
<footer class="site-footer"><div class="container"><p>&copy; <?php echo date('Y'); ?> WP Library — Educational Project</p></div></footer>
</body></html>