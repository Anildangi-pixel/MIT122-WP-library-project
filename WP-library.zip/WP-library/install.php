<?php
$host='localhost'; $db='library_db'; $user='root'; $pass='';
try {
    $pdo = new PDO('mysql:host=' . $host, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE `$db`;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(100) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL, is_admin TINYINT(1) DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS books (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, author VARCHAR(255) NOT NULL, category VARCHAR(100), description TEXT, image VARCHAR(255), available TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS borrows (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, book_id INT NOT NULL, borrow_date DATE, due_date DATE, return_date DATE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE) ENGINE=InnoDB;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS messages (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, subject VARCHAR(255) NOT NULL, message TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB;");
    $pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, token VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB;");
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = ?'); $stmt->execute(['admin@admin.com']);
    if (!$stmt->fetchColumn()) { $stmt = $pdo->prepare('INSERT INTO users (name,email,password,is_admin) VALUES (?, ?, ?, 1)'); $stmt->execute(['Admin','admin@admin.com',$hash]); }
    $books = [
        ['To Kill a Mockingbird','Harper Lee','Fiction','A timeless novel exploring themes of racial injustice and moral growth.','image1.png'],
        ['1984','George Orwell','Dystopian','A dystopian classic depicting a totalitarian society under constant surveillance.','image2.png'],
        ['Pride and Prejudice','Jane Austen','Romance','A romantic novel highlighting manners, morality, and marriage in 19th-century England.','image3.png'],
        ['The Great Gatsby','F. Scott Fitzgerald','Fiction','A story about wealth, love, and the American Dream in the Roaring Twenties.','image4.png'],
        ['Moby-Dick','Herman Melville','Adventure','The saga of Captain Ahab’s obsessive quest to hunt the white whale.','image5.png'],
        ['The Catcher in the Rye','J.D. Salinger','Fiction','A coming-of-age story about teenage alienation and rebellion.','image6.png'],
        ['The Hobbit','J.R.R. Tolkien','Fantasy','A fantasy adventure about Bilbo Baggins and his journey to reclaim a treasure.','image7.png'],
        ['Frankenstein','Mary Shelley','Gothic','A gothic tale about science, creation, and the consequences of playing god.','image8.png'],
        ['The Odyssey','Homer','Epic','An epic poem following Odysseus\' long journey home after the Trojan War.','image9.png'],
    ];
    $stmt = $pdo->prepare('INSERT INTO books (title,author,category,description,image,available) VALUES (?,?,?,?,?,1)');
    foreach ($books as $b) {
        $check = $pdo->prepare('SELECT COUNT(*) FROM books WHERE title = ? AND author = ?'); $check->execute([$b[0],$b[1]]);
        if (!$check->fetchColumn()) $stmt->execute($b);
    }
    echo "<h2>Install successful</h2><p>Database and sample data created. Default admin: <strong>admin@admin.com</strong> / <strong>admin123</strong></p><p>Delete install.php after running it.</p>";
} catch (PDOException $e) { die('Install failed: ' . $e->getMessage()); }
?>