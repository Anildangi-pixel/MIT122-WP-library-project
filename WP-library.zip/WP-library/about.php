<?php require_once __DIR__ . '/includes/header.php'; ?>
<link rel="stylesheet" href="css/style.css">
<!-- Hero Section -->
<section class="about-hero">
  <img src="images/about-bg.jpg" alt="Library Background" class="about-bg"> <!-- Replace with your image -->
  <div class="overlay"></div>
  <div class="about-hero-text">
    <h2>About WP Library</h2>
    <p>Your digital gateway to knowledge, learning, and discovery.</p>
  </div>
</section>

<!-- About Boxes -->
<section class="about-boxes">
  <div class="about-box">
    <h3>📖 Who We Are</h3>
    <p>WP Library is a modern online library designed to make knowledge accessible to everyone. 
       From students and teachers to book enthusiasts, we provide thousands of resources at your fingertips.</p>
  </div>

  <div class="about-box">
    <h3>🎯 Our Mission</h3>
    <p>Our mission is to empower people with unlimited access to books, study materials, and educational resources, 
       anytime and anywhere. We believe learning should be simple, engaging, and borderless.</p>
  </div>

  <div class="about-box">
    <h3>✨ What We Offer</h3>
    <ul>
      <li>Thousands of digital books across various categories</li>
      <li>Easy search and filter system for quick access</li>
      <li>User-friendly design, accessible on all devices</li>
      <li>24/7 access, from anywhere in the world</li>
    </ul>
  </div>
</section>

<!-- Team Section -->
<section class="team">
  <h3>👩‍💻 Meet Our Team</h3>
  <div class="team-grid">
    <div class="team-card">
      <h4>Anil DANGI</h4>
      <p>Founder & Developer</p>
    </div>
    <div class="team-card">
      <h4>Bhuwan Paudel</h4>
      <p>Content Manager</p>
    </div>
  </div>
  <p class="disclaimer">
    * Team information is for demo purposes only. The books and authors available in WP Library are real.
  </p>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>