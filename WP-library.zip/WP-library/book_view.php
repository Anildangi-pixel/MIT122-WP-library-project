<?php require_once __DIR__ . '/includes/header.php';
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { setFlash('error','Invalid book ID'); redirect('books.php'); }
$id = (int)$_GET['id']; $stmt = $pdo->prepare('SELECT * FROM books WHERE id = ?'); $stmt->execute([$id]); $book = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$book) { setFlash('error','Book not found'); redirect('books.php'); }
?>
<article class="book-detail"><div class="book-left"><img src="images/<?php echo esc($book['image']); ?>" alt=""></div><div class="book-right"><h2><?php echo esc($book['title']); ?></h2><p class="author">By <?php echo esc($book['author']); ?></p><p class="muted">Category: <?php echo esc($book['category']); ?></p><p><?php echo nl2br(esc($book['description'])); ?></p><p><strong>Available:</strong> <?php echo $book['available'] ? 'Yes' : 'No'; ?></p>
<?php if ($book['available']): if (isLoggedIn()): ?><form method="post" action="borrow.php"><input type="hidden" name="book_id" value="<?php echo esc($book['id']); ?>"><button type="submit" class="btn">Borrow this book</button></form><?php else: ?><p><a href="login.php">Login</a> to borrow this book.</p><?php endif; else: ?><p class="muted">This book is currently borrowed.</p><?php endif; ?>
</div></article>
<section><h3>Recommended Books</h3><div class="book-grid"><?php $recommended = getRecommendedBooks($book['id'],4); foreach($recommended as $r): ?><article class="book-card"><a href="book_view.php?id=<?php echo esc($r['id']); ?>"><img src="images/<?php echo esc($r['image']); ?>" alt=""><h4><?php echo esc($r['title']); ?></h4></a><p class="author"><?php echo esc($r['author']); ?></p></article><?php endforeach; ?></div></section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>