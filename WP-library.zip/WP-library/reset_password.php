<?php require_once __DIR__ . '/includes/header.php';
$token = $_GET['token'] ?? ''; if (!$token) { setFlash('error','No token provided.'); redirect('login.php'); }
$stmt = $pdo->prepare('SELECT pr.user_id, u.email FROM password_resets pr JOIN users u ON pr.user_id = u.id WHERE pr.token = ?'); $stmt->execute([$token]); $row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) { setFlash('error','Invalid or expired token.'); redirect('login.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw1 = $_POST['password'] ?? ''; $pw2 = $_POST['password2'] ?? '';
    if ($pw1=='' || $pw1 !== $pw2) { setFlash('error','Passwords do not match or are empty.'); redirect('reset_password.php?token=' . urlencode($token)); }
    $hash = password_hash($pw1,PASSWORD_DEFAULT); $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?'); $stmt->execute([$hash,$row['user_id']]);
    $stmt = $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?'); $stmt->execute([$row['user_id']]); setFlash('success','Password updated. You can login now.'); redirect('login.php');
}
?>
<h2>Reset Password for <?php echo esc($row['email']); ?></h2>
<form method="post" class="form"><label>New password<input type="password" name="password" required></label><label>Confirm password<input type="password" name="password2" required></label><button type="submit">Set new password</button></form>
<?php require_once __DIR__ . '/includes/footer.php'; ?>