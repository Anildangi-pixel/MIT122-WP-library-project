<?php require_once __DIR__ . '/includes/header.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $subject = trim($_POST['subject'] ?? ''); $message = trim($_POST['message'] ?? '');
    if ($name=='' || $email=='' || $subject=='' || $message=='') { setFlash('error','Please fill all fields.'); redirect('contact.php'); }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { setFlash('error','Invalid email'); redirect('contact.php'); }
    // If user logged in, associate message with user_id, else user_id = NULL (we store 0)
    $uid = $_SESSION['user_id'] ?? 0;
    $stmt = $pdo->prepare('INSERT INTO messages (user_id, subject, message) VALUES (?, ?, ?)');
    $stmt->execute([$uid, $subject, "From: $name ($email)\n\n" . $message]);
    setFlash('success','Message sent. Thank you.'); redirect('contact.php');
}
?>
<h2>Contact Us</h2>
<form method="post" class="form">
  <label>Name<input type="text" name="name" required></label>
  <label>Email<input type="email" name="email" required></label>
  <label>Subject<input type="text" name="subject" required></label>
  <label>Message<textarea name="message" rows="5" required></textarea></label>
  <button type="submit">Send Message</button>
</form>
<?php require_once __DIR__ . '/includes/footer.php'; ?>