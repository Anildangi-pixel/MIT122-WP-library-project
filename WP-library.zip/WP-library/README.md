# WP Library (PHP)

WP Library is an educational online library management system. See PROJECT_PROPOSAL.md for details.

See install instructions in install.php.
