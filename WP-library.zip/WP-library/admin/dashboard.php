<?php require_once __DIR__ . '/../includes/functions.php'; if (!isLoggedIn()||!isAdmin()){ setFlash('error','Admin access only.'); redirect('/WP-library/login.php'); } require_once __DIR__ . '/../includes/header.php';
$totalBooks = $pdo->query('SELECT COUNT(*) FROM books')->fetchColumn(); $totalUsers = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(); $totalMessages = $pdo->query('SELECT COUNT(*) FROM messages')->fetchColumn();
?>
<h2>Admin Dashboard</h2>
<div class="admin-cards"><div class="card"><h3><?php echo (int)$totalBooks; ?></h3><p>Books</p></div><div class="card"><h3><?php echo (int)$totalUsers; ?></h3><p>Users</p></div><div class="card"><h3><?php echo (int)$totalMessages; ?></h3><p>Messages</p></div></div>
<p><a href="add_book.php" class="btn">Add Book</a> <a href="remove_book.php" class="btn">Remove Book</a> <a href="view_messages.php" class="btn">View Messages</a></p>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>