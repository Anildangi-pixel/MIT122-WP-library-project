<?php require_once __DIR__ . '/../includes/functions.php'; if (!isLoggedIn()||!isAdmin()){ setFlash('error','Admin access only.'); redirect('/WP-library/login.php'); } require_once __DIR__ . '/../includes/header.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $title=trim($_POST['title'] ?? ''); $author=trim($_POST['author'] ?? ''); $category=trim($_POST['category'] ?? ''); $description=trim($_POST['description'] ?? '');
    if ($title==''||$author=='') { setFlash('error','Please fill title and author.'); redirect('add_book.php'); }
    $imageName = '';
    if (!empty($_FILES['image']['name'])) { $targetDir = __DIR__ . '/../images/'; $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION); $imageName = 'book_' . time() . '.' . $ext; move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $imageName); } else { $imageName = 'image1.png'; }
    $stmt = $pdo->prepare('INSERT INTO books (title,author,category,description,image,available) VALUES (?,?,?,?,?,1)'); $stmt->execute([$title,$author,$category,$description,$imageName]);
    setFlash('success','Book added.'); redirect('dashboard.php');
}
?>
<h2>Add Book</h2>
<form method="post" enctype="multipart/form-data" class="form"><label>Title<input type="text" name="title" required></label><label>Author<input type="text" name="author" required></label><label>Category<input type="text" name="category"></label><label>Description<textarea name="description" rows="4"></textarea></label><label>Cover image (optional)<input type="file" name="image" accept="image/*"></label><button type="submit">Add Book</button></form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>