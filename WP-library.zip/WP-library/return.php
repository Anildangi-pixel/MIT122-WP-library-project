<?php require_once __DIR__ . '/includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { setFlash('error','Invalid request'); redirect('account.php'); }
if (!isLoggedIn()) { setFlash('error','Please login'); redirect('login.php'); }
$borrow_id = (int)($_POST['borrow_id'] ?? 0);
// Fetch borrow record and ensure belongs to user and not already returned
$stmt = $pdo->prepare('SELECT id, book_id, return_date, user_id FROM borrows WHERE id = ?');
$stmt->execute([$borrow_id]); $br = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$br || $br['user_id'] != $_SESSION['user_id']) { setFlash('error','Invalid borrow record'); redirect('account.php'); }
if ($br['return_date']) { setFlash('error','Already returned'); redirect('account.php'); }
// Set return_date and mark book available
$stmt = $pdo->prepare('UPDATE borrows SET return_date = CURDATE() WHERE id = ?'); $stmt->execute([$borrow_id]);
$stmt = $pdo->prepare('UPDATE books SET available = 1 WHERE id = ?'); $stmt->execute([$br['book_id']]);
setFlash('success','Book returned successfully.'); redirect('account.php'); ?>