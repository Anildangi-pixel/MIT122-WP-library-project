<?php require_once __DIR__ . '/includes/header.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email=trim($_POST['email'] ?? ''); $password=$_POST['password'] ?? '';
    if ($email==''||$password=='') { setFlash('error','Please provide email and password.'); redirect('login.php'); }
    $stmt = $pdo->prepare('SELECT id,name,email,password,is_admin FROM users WHERE email = ?'); $stmt->execute([$email]); $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user || !password_verify($password,$user['password'])) { setFlash('error','Invalid credentials.'); redirect('login.php'); }
    $_SESSION['user_id']=$user['id']; $_SESSION['user_name']=$user['name']; $_SESSION['is_admin']=(bool)$user['is_admin']; setFlash('success','Logged in successfully.'); redirect('index.php');
}
?>
<h2>Login</h2>
<form method="post" class="form"><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button type="submit">Login</button></form><p><a href="forgot_password.php">Forgot password?</a></p>
<?php require_once __DIR__ . '/includes/footer.php'; ?>