<?php require_once __DIR__ . '/includes/header.php'; if (!isLoggedIn()) { setFlash('error','Please login first.'); redirect('login.php'); } $user = getUserById($_SESSION['user_id']);
// Borrowed records (including return_date)
$stmt = $pdo->prepare('SELECT bo.id as borrow_id, b.*, bo.borrow_date, bo.due_date, bo.return_date FROM borrows bo JOIN books b ON bo.book_id = b.id WHERE bo.user_id = ? ORDER BY bo.borrow_date DESC');
$stmt->execute([$_SESSION['user_id']]); $borrows = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Handle sending message (same as before)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message_subject'])) {
    $subject = trim($_POST['message_subject']); $message = trim($_POST['message_body']);
    if ($subject==''||$message=='') { setFlash('error','Please enter subject and message.'); redirect('account.php'); }
    $stmt = $pdo->prepare('INSERT INTO messages (user_id, subject, message) VALUES (?, ?, ?)');
    $stmt->execute([$_SESSION['user_id'],$subject,$message]); setFlash('success','Message sent to admin.'); redirect('account.php');
}
?>
<h2>My Account</h2>
<p>Hello, <?php echo esc($user['name']); ?> (<?php echo esc($user['email']); ?>)</p>
<section><h3>Borrowed Books</h3>
<?php if ($borrows): ?><ul class="borrow-list"><?php foreach($borrows as $br): ?><li><strong><?php echo esc($br['title']); ?></strong> — borrowed on <?php echo esc($br['borrow_date']); ?> | Due: <?php echo esc($br['due_date']); ?> <?php if(!$br['return_date']): ?><form method="post" action="return.php" style="display:inline"><input type="hidden" name="borrow_id" value="<?php echo esc($br['borrow_id']); ?>"><button type="submit" class="btn">Return</button></form><?php else: ?> <span class="muted">Returned on <?php echo esc($br['return_date']); ?></span><?php endif; ?></li><?php endforeach; ?></ul><?php else: ?><p>You have not borrowed any books yet.</p><?php endif; ?></section>
<section><h3>Send a message to admin</h3><form method="post" class="form"><label>Subject<input type="text" name="message_subject" required></label><label>Message<textarea name="message_body" rows="4" required></textarea></label><button type="submit">Send Message</button></form></section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>